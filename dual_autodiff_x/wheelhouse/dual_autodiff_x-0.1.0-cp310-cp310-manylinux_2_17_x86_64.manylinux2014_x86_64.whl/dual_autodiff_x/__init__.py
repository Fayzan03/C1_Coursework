
# Import the main Dual class
from .dual import Dual

# Print the package version for confirmation
print("dual_autodiff_x package version: 0.1.0")